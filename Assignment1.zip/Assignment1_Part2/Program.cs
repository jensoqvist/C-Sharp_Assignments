﻿namespace Assignment1_Part2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Guitar guitar = new Guitar();
            guitar.Start();
        }
    }
}